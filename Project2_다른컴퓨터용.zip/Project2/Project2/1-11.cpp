#define _CRT_SECURE_NO_WARNINGS
#include <GL/glew.h>
#include <GL/glfw3.h>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

//--- �ݹ� �Լ�
void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods);
void MouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void GetCursorPose(GLFWwindow* window, double xpos, double ypos);

//--- ���̴� ���� �Լ�
std::string filetobuf(const char* filePath);
void make_vertexShaders();
void make_fragmentShaders();
GLuint make_shaderProgram();
GLvoid drawScene();

//--- �ʿ��� ���� ����
GLint width, height;
GLuint shaderProgramID;
GLuint vertexShader;
GLuint fragmentShader;
GLuint VAO;

int winrow, wincol,px,py;
float speed=1.0f;
double lastMove=0;

typedef struct Col {
	float x, y, r, g, b,scalex,scaley,obr,obg,obb,obsize,pr,pg,pb,psize;
	bool isPassed,isPlayer,iscollision;
	int isObstacle,playerType;
}Col;

typedef struct Row {
	Col col[30];
}Row;

Row row[30];
bool isS=false;
int main(void)
{
	srand((unsigned int)time(NULL));

	GLFWwindow* window;
	GLenum glewResult;

	width = 1200;
	height = 1200;

	//--- GLFW �ʱ�ȭ
	if (glfwInit() != GLFW_TRUE)
	{
		printf("GLFW initialization failed.\n");
		return EXIT_FAILURE;
	}

	//--- OpenGL ���� ����
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	printf("���� ���̸� �Է��ϼ��� ( 10 ~ 30 ) : ");
	scanf("%d", &wincol);
	printf("���� ���̸� �Է��ϼ��� ( 10 ~ 30 ) : ");
	scanf("%d", &winrow);
	width = wincol * 40;
	height = winrow * 40;

	for (int i = 0;i < winrow;i++)
	{
		for (int j = 0;j < wincol;j++)
		{
			int random = rand() % 10;
			row[i].col[j].x = -1.0f + (j + 0.5f) * (2.0f / wincol);
			row[i].col[j].y = 1.0f - (i + 0.5f) * (2.0f / winrow);

			row[i].col[j].scalex = 2.0f/wincol;
			row[i].col[j].scaley = 2.0f/winrow;

			row[i].col[j].r = 0.0f;
			row[i].col[j].g = 0.0f;
			row[i].col[j].b = 0.0f;

			row[i].col[j].obr = (float)rand() / RAND_MAX;
			row[i].col[j].obg = (float)rand() / RAND_MAX;
			row[i].col[j].obb = (float)rand() / RAND_MAX;

			row[i].col[j].pr = (float)rand() / RAND_MAX;
			row[i].col[j].pg = (float)rand() / RAND_MAX;
			row[i].col[j].pb = (float)rand() / RAND_MAX;

			row[i].col[j].obsize = 0.5f + (float)rand() / RAND_MAX * 0.3f;

			if (random == 0)
				row[i].col[j].isObstacle = 1;
			else if (random == 1)
				row[i].col[j].isObstacle = 2;
			else if (random == 2)
				row[i].col[j].isObstacle = 3;
			else
				row[i].col[j].isObstacle = 0;
		}
	}

	row[0].col[0].isPlayer = true;
	row[0].col[0].playerType = 1;
	row[0].col[0].psize = 0.8f;
	row[0].col[0].isObstacle = 0;
	//--- ������ ����
	window = glfwCreateWindow(width, height, "OpenGL Basic Window (C++)", NULL, NULL);
	if (window == NULL)
	{
		printf("Window creation failed.\n");
		glfwTerminate();
		return EXIT_FAILURE;
	}

	glfwSetWindowPos(window, 20, 50);

	//--- OpenGL ���ؽ�Ʈ ����
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);

	//--- GLEW �ʱ�ȭ
	glewExperimental = GL_TRUE;
	glewResult = glewInit();
	if (glewResult != GLEW_OK)
	{
		printf("GLEW initialization failed: %s\n",
			(const char*)glewGetErrorString(glewResult));
		glfwDestroyWindow(window);
		glfwTerminate();
		return EXIT_FAILURE;
	}

	//--- �ݹ� �Լ� ���
	glfwSetKeyCallback(window, keyCallback);
	glfwSetMouseButtonCallback(window, MouseButtonCallback);
	glfwSetCursorPosCallback(window, GetCursorPose);

	//--- ����Ʈ ����
	glViewport(0, 0, width, height);

	//--- VAO ���� �� ���ε�
	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);

	//--- ���̴� �о�ͼ� ���̴� ���α׷� �����
	make_vertexShaders();
	make_fragmentShaders();
	shaderProgramID = make_shaderProgram();

	//--- ���� ����
	while (glfwWindowShouldClose(window) == GLFW_FALSE)
	{
		//--- ȭ�� ���
		drawScene();

		//--- Q Ű�� ������ ����
		if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		{
			glfwSetWindowShouldClose(window, GLFW_TRUE);
		}

		//--- ���� ��ü �� �̺�Ʈ ó��
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	//--- ���� ó��
	glDeleteProgram(shaderProgramID);
	glDeleteVertexArrays(1, &VAO);
	glfwDestroyWindow(window);
	glfwTerminate();

	return EXIT_SUCCESS;
}

//--- ���ؽ� ���̴� ��ü �����
void make_vertexShaders()
{
	//--- ���̴� �ڵ� �о����
	std::string vertexSource = filetobuf("vertex4.glsl");
	const char* source = vertexSource.c_str();

	//--- ���̴� �����ϱ�
	vertexShader = glCreateShader(GL_VERTEX_SHADER);

	//--- ���̴��� �ڵ� �����ϰ� ������ �ϱ�
	glShaderSource(vertexShader, 1, &source, NULL);
	glCompileShader(vertexShader);

	GLint result;
	GLchar errorLog[512];

	//--- ���� üũ�ϱ�
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &result);
	if (!result)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, errorLog);
		std::cerr << "ERROR: vertex shader ������ ����\n" << errorLog << std::endl;
		return;
	}
}

//--- �����׸�Ʈ ���̴� ��ü �����
void make_fragmentShaders()
{
	//--- ���̴� �ڵ� �о����
	std::string fragmentSource = filetobuf("fragment.glsl");
	const char* source = fragmentSource.c_str();

	//--- ���̴� �����ϱ�
	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);

	//--- ���̴��� �ڵ� �����ϰ� ������ �ϱ�
	glShaderSource(fragmentShader, 1, &source, NULL);
	glCompileShader(fragmentShader);

	GLint result;
	GLchar errorLog[512];

	//--- ���� üũ�ϱ�
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &result);
	if (!result)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, errorLog);
		std::cerr << "ERROR: fragment shader ������ ����\n" << errorLog << std::endl;
		return;
	}
}

//--- ���̴� ���α׷� ����� ���̴� ��ü ��ũ�ϱ�
GLuint make_shaderProgram()
{
	GLint result;
	GLchar errorLog[512];

	//--- ���̴� ���α׷� ����
	GLuint shaderID = glCreateProgram();

	//--- ���ؽ� ���̴��� �����׸�Ʈ ���̴� ����
	glAttachShader(shaderID, vertexShader);
	glAttachShader(shaderID, fragmentShader);

	//--- ���̴� ���α׷� ��ũ
	glLinkProgram(shaderID);

	//--- ��ũ�� �������Ƿ� ���̴� ��ü ����
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	//--- ��ũ ���� ���� Ȯ��
	glGetProgramiv(shaderID, GL_LINK_STATUS, &result);
	if (!result)
	{
		glGetProgramInfoLog(shaderID, 512, NULL, errorLog);
		std::cerr << "ERROR: shader program ���� ����\n" << errorLog << std::endl;
		return 0;
	}

	//--- ���̴� ���α׷� ���
	glUseProgram(shaderID);
	return shaderID;
}

//--- ��� �Լ�
GLvoid drawScene()
{
	//--- ��� ������� ȭ�� �����
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	//--- ���̴� ���α׷� ���
	glUseProgram(shaderProgramID);

	GLint offsetLocation = glGetUniformLocation(shaderProgramID, "offset");
	GLint scaleLocation = glGetUniformLocation(shaderProgramID, "scale");
	GLint colorLocation = glGetUniformLocation(shaderProgramID, "vColor");

	//--- �� �Ʒ��� �ʿ��� �׸��� ����� �߰�
	for (int i = 0;i < winrow;i++)
	{
		for (int j = 0;j < wincol;j++)
		{
			if (row[i].col[j].iscollision == false)
			{
				glUniform2f(offsetLocation, row[i].col[j].x, row[i].col[j].y);
				glUniform2f(scaleLocation, row[i].col[j].scalex, row[i].col[j].scaley);
				glUniform4f(colorLocation, row[i].col[j].r, row[i].col[j].g, row[i].col[j].b, 1.0f);
				glDrawArrays(GL_LINE_LOOP, 0, 4);
			}
			else
			{
				glUniform2f(offsetLocation, row[i].col[j].x, row[i].col[j].y);
				glUniform2f(scaleLocation, row[i].col[j].scalex, row[i].col[j].scaley);
				glUniform4f(colorLocation, 1.0f, 0, 0, 1.0f);
				glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
			}


			if (row[i].col[j].isObstacle == 1)
			{
				glUniform2f(scaleLocation, row[i].col[j].scalex * row[i].col[j].obsize, row[i].col[j].scaley * row[i].col[j].obsize);
				glUniform4f(colorLocation, row[i].col[j].obr, row[i].col[j].obg, row[i].col[j].obb, 1.0f);
				glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
			}
			else if (row[i].col[j].isObstacle == 2)
			{
				glUniform2f(scaleLocation, row[i].col[j].scalex * row[i].col[j].obsize, row[i].col[j].scaley * row[i].col[j].obsize);
				glUniform4f(colorLocation, row[i].col[j].obr, row[i].col[j].obg, row[i].col[j].obb, 1.0f);
				glDrawArrays(GL_TRIANGLES, 4, 3);
			}
			else if (row[i].col[j].isObstacle == 3)
			{
				glUniform2f(scaleLocation, row[i].col[j].scalex * row[i].col[j].obsize, row[i].col[j].scaley * row[i].col[j].obsize);
				glUniform4f(colorLocation, row[i].col[j].obr, row[i].col[j].obg, row[i].col[j].obb, 1.0f);
				glDrawArrays(GL_TRIANGLES, 7, 3);
			}

			if (row[i].col[j].isPlayer)
			{
				glUniform2f(scaleLocation, row[i].col[j].scalex * row[i].col[j].psize, row[i].col[j].scaley * row[i].col[j].psize);
				glUniform4f(colorLocation, row[i].col[j].pr, row[i].col[j].pg, row[i].col[j].pb, 1.0f);
				if (row[i].col[j].playerType == 1)
					glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
				else if (row[i].col[j].playerType == 2)
					glDrawArrays(GL_TRIANGLES, 4, 3);
				else if (row[i].col[j].playerType == 3)
					glDrawArrays(GL_TRIANGLES, 7, 3);
			}
		}
	}

	double now = glfwGetTime();
	if (isS == false)
	{
		if (now - lastMove > speed)
		{
			int nextX = px;
			int nextY = py;

			if (py % 2 == 0 && px < wincol - 1)
				nextX++;
			else if (py % 2 == 1 && px > 0)
				nextX--;
			else if (py < winrow - 1)
				nextY++;

			if (nextX != px || nextY != py)
			{
				for (int i = 0; i < winrow; i++)
				{
					for (int j = 0; j < wincol; j++)
					{
						if (i == py && j == px)
						{
							row[nextY].col[nextX].psize = row[i].col[j].psize;
							row[nextY].col[nextX].pr = row[i].col[j].pr;
							row[nextY].col[nextX].pg = row[i].col[j].pg;
							row[nextY].col[nextX].pb = row[i].col[j].pb;
							row[nextY].col[nextX].playerType = row[i].col[j].playerType;

							row[i].col[j].isPlayer = false;
							row[i].col[j].iscollision = false;
							row[nextY].col[nextX].isPlayer = true;

							if (row[nextY].col[nextX].isObstacle != 0)
							{
								float tsize = row[nextY].col[nextX].psize;
								float tr = row[nextY].col[nextX].pr;
								float tg = row[nextY].col[nextX].pg;
								float tb = row[nextY].col[nextX].pb;
								int ttype = row[nextY].col[nextX].playerType;

								row[nextY].col[nextX].psize = row[nextY].col[nextX].obsize;
								row[nextY].col[nextX].pr = row[nextY].col[nextX].obr;
								row[nextY].col[nextX].pg = row[nextY].col[nextX].obg;
								row[nextY].col[nextX].pb = row[nextY].col[nextX].obb;
								row[nextY].col[nextX].playerType = row[nextY].col[nextX].isObstacle;

								row[nextY].col[nextX].obsize = tsize;
								row[nextY].col[nextX].obr = tr;
								row[nextY].col[nextX].obg = tg;
								row[nextY].col[nextX].obb = tb;
								row[nextY].col[nextX].isObstacle = ttype;

								row[nextY].col[nextX].iscollision = true;
							}
						}
					}
				}
				px = nextX;
				py = nextY;
			}
			else
			{
				row[py].col[px].iscollision = false;
			}
			lastMove = now;
		}
	}
	

}

//--- Ű���� �Է� �ݹ� �Լ�
void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if ((key == GLFW_KEY_EQUAL && (mods & GLFW_MOD_SHIFT)) || key == GLFW_KEY_KP_ADD)
	{
		if (speed >= 0.2f)
			speed -= 0.1f;
	}
	else if (key == GLFW_KEY_MINUS || key == GLFW_KEY_KP_SUBTRACT)
	{
		if (speed < 1.5f)
			speed += 0.1f;
	}

	if (key == GLFW_KEY_S && action == GLFW_PRESS)
	{
		isS = !isS;
	}
}

//--- ���콺 ��ư �Է� �ݹ� �Լ�
void MouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
	{

	}
	else if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
	{

	}
	else if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE)
	{

	}
}

//--- ���콺 ��ġ �Է� �ݹ� �Լ�
void GetCursorPose(GLFWwindow* window, double xpos, double ypos)
{
	if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS)
	{

	}
}

//--- �ؽ�Ʈ ������ ������ ���ڿ��� �о���� �Լ�
std::string filetobuf(const char* filePath)
{
	std::ifstream file(filePath);
	std::ostringstream buffer;
	buffer << file.rdbuf();
	return buffer.str();
}
